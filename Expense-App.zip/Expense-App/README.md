This is an expense tracking app.

Technology used: JavaScript, ReactJs, NodeJs, Express, MongoDB, Passport.js, Graphql.

You can access the app using this link: https://expense-app-busj.onrender.com
